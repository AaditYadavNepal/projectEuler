package com.example.aadityadav.assignment04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class cycleActivity extends AppCompatActivity {


    TextView origi;
    EditText edt1;
    TextView repa1;
    String originalS;
    String fina="";
    String cy="";
    String rsult="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cycle);
        origi=(TextView)findViewById(R.id.coriginal);
        Intent intent = getIntent();
        originalS = intent.getExtras().getString("sourceT1");
        origi.setText(originalS);
    }

    public void showFunction(View v) {
        edt1=(EditText)findViewById(R.id.numcycles);
        repa1=(TextView)findViewById(R.id.cchanged);

        String wh=edt1.getText().toString();
        int num=Integer.parseInt(wh);

        for(int i=0; i<originalS.length();i++)
        {
            if(i<num)
            {
                cy+=originalS.charAt(i);
            }
            else
            {
                fina+=originalS.charAt(i);
            }
        }

        rsult=fina+" "+cy;
        repa1.setText(rsult.toString());

    }

    public void cancelFunction(View v)
    {
        Intent inti=new Intent();
        inti.putExtra("failurecodecycle","error");
        setResult(37,inti);
        finish();
    }

    public void applyFunction(View v)
    {
        Intent inti=new Intent();
        inti.putExtra("successcycle",rsult);
        setResult(38,inti);
        finish();
    }


}
