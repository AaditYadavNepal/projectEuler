package com.example.aadityadav.assignment04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class replaceActivity extends AppCompatActivity {

    TextView orig;
    EditText et1;
    EditText et2;
    TextView rep1;
    String original;
    String fin = "";
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replace);
        orig = (TextView) findViewById(R.id.roriginal);
        Intent intent = getIntent();
        original = intent.getExtras().getString("sourceT");
        orig.setText(original);
    }

    public void showFunction(View v) {
        et1 = (EditText) findViewById(R.id.what);
        et2 = (EditText) findViewById(R.id.by);
        rep1 = (TextView) findViewById(R.id.rchanged);

        String wh = et1.getText().toString();
        String by = et2.getText().toString();

        if (counter < 3) {
            if (original.toLowerCase().contains(wh.toLowerCase())) {
                fin = original.replace(wh, by);
            }

            rep1.setText(fin);
        } else {
            Toast.makeText(replaceActivity.this, "You have completed your attempts to replace the string",
                    Toast.LENGTH_SHORT).show();
        }
        counter++;
    }

    public void cancelFunction(View v) {
        Intent inti = new Intent();
        inti.putExtra("failurecode", "error");
        setResult(35, inti);
        finish();
    }

    public void applyFunction(View v) {
        Intent inti = new Intent();
        inti.putExtra("success", fin);
        setResult(36, inti);
        finish();
    }



}
