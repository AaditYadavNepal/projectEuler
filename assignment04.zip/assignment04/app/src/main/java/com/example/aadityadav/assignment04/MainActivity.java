package com.example.aadityadav.assignment04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText sr;
    String res;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void replaceFunction(View v) {

        sr=(EditText)findViewById(R.id.mainText);
        String sourceText=sr.getText().toString();
        if(sourceText.equals(""))
        {
            Toast.makeText(MainActivity.this, "Please enter a valid string",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Intent init = new Intent(this, replaceActivity.class);
            init.putExtra("sourceT",sourceText);
            startActivityForResult(init, 07);
        }
    }

    public void cycleFunction(View v) {
        sr=(EditText)findViewById(R.id.mainText);
        String sourceText=sr.getText().toString();
        if(sourceText.equals(""))
        {
            Toast.makeText(MainActivity.this, "Please enter a valid string",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Intent init = new Intent(this, cycleActivity.class);
            init.putExtra("sourceT1",sourceText);
            startActivityForResult(init, 19);
        }
    }

    public void trimFunction(View v) {
        sr=(EditText)findViewById(R.id.mainText);
        String sourceText=sr.getText().toString();
        if(sourceText.equals(""))
        {
            Toast.makeText(MainActivity.this, "Please enter a valid string",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Intent init = new Intent(this, trimActivity.class);
            init.putExtra("sourceT2",sourceText);
            startActivityForResult(init, 21);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        sr=(EditText)findViewById(R.id.mainText);

        if (requestCode == 07 && resultCode == 35 && data != null) {
            Toast.makeText(MainActivity.this, "No action is performed as cancel button is pressed",
                    Toast.LENGTH_SHORT).show();
        }
        else if (requestCode == 07 && resultCode == 36 && data != null) {
            res = data.getStringExtra("success");
        }

        else if (requestCode == 19 && resultCode == 37 && data != null) {
            Toast.makeText(MainActivity.this, "No action is performed as cancel button is pressed",
                    Toast.LENGTH_SHORT).show();
        }

        else if (requestCode == 19 && resultCode == 38 && data != null) {
            res = data.getStringExtra("successcycle");
        }

        else if (requestCode == 21 && resultCode == 39 && data != null) {
            Toast.makeText(MainActivity.this, "No action is performed as cancel button is pressed",
                    Toast.LENGTH_SHORT).show();
        }

        else if (requestCode == 21 && resultCode == 40 && data != null) {
            res = data.getStringExtra("successtrim");
        }

        sr.setText(res);
    }

    public void resetFunction(View v)
    {
        sr=(EditText)findViewById(R.id.mainText);
        sr.setText("");
    }
}
