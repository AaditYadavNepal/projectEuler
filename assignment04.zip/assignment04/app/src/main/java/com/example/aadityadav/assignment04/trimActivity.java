package com.example.aadityadav.assignment04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class trimActivity extends AppCompatActivity {

    TextView orig;
    EditText et1;
    EditText et2;
    TextView rep1;
    String original;
    String fin="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trim);
        orig=(TextView)findViewById(R.id.roriginal2);
        Intent intent = getIntent();
        original = intent.getExtras().getString("sourceT2");
        orig.setText(original);
    }

    public void showFunction(View v) {
        et1=(EditText)findViewById(R.id.startpos);
        et2=(EditText)findViewById(R.id.endpos);
        rep1=(TextView)findViewById(R.id.rchanged2);

        String wh=et1.getText().toString();
        String by=et2.getText().toString();

        int st=Integer.parseInt(wh);
        int en=Integer.parseInt(by);

        for(int i=0; i<original.length();i++)
        {
            if(i<st)
            {
                continue;
            }
            else if(i>=original.length()-en)
            {
                continue;
            }
            fin+=original.charAt(i);
        }

        rep1.setText(fin);

    }

    public void cancelFunction(View v)
    {
        Intent inti=new Intent();
        inti.putExtra("failurecodetrim","error");
        setResult(39,inti);
        finish();
    }

    public void applyFunction(View v)
    {
        Intent inti=new Intent();
        inti.putExtra("successtrim",fin);
        setResult(40,inti);
        finish();
    }
}
